const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const mysql = require("mysql");
const path = require("path");

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const connection = mysql.createConnection({
    host: 'ucka.veleri.hr',
    user: 'bkovacevic',
    password: '11',
    database: 'Automobili_tc'
});

connection.connect(function (err) {
    if (err) throw err;
    console.log("Connected to Automobili_tc!");
});

// API za dohvaćanje svih automobila
app.get("/api/automobili", (req, res) => {
    connection.query("SELECT * FROM Automobili", (error, results) => {
        if (error) throw error;
        res.send(results);
    });
});

// API za dohvaćanje automobila po ID-u
app.get("/api/automobil/:id", (req, res) => {
    const id = req.params.id;
    connection.query("SELECT * FROM Automobili WHERE id = ?", [id], (error, results) => {
        if (error) throw error;
        res.send(results);
    });
});

// API za dodavanje automobila
app.post("/api/dodaj_automobil", (req, res) => {
    const { marka, model, godiste, cena, slika, opis } = req.body;
    const noviAuto = [[marka, model, godiste, cena, slika, opis]];

    connection.query(
        "INSERT INTO Automobili (marka, model, godiste, cena, slika, opis) VALUES ?",
        [noviAuto],
        (error, results) => {
            if (error) throw error;
            res.send({ message: "Automobil uspešno dodat", results });
        }
    );
});

// API za brisanje automobila
app.delete("/api/obrisi_automobil/:id", (req, res) => {
    const id = req.params.id;
    connection.query("DELETE FROM Automobili WHERE id = ?", [id], (error, results) => {
        if (error) throw error;
        if (results.affectedRows === 0) {
            return res.status(404).send({ message: "Automobil nije pronađen" });
        }
        res.send({ message: "Automobil uspešno obrisan" });
    });
});

// API za registraciju korisnika
app.post("/api/registracija", (req, res) => {
    const { ime, prezime, korisnickoIme, lozinka } = req.body;
    const noviKorisnik = [[ime, prezime, korisnickoIme, lozinka]];

    connection.query("SELECT * FROM Korisnici WHERE korisnickoIme = ?", [korisnickoIme], (error, results) => {
        if (error) throw error;

        if (results.length > 0) {
            return res.status(400).json({ message: "Korisničko ime već postoji" });
        }

        connection.query(
            "INSERT INTO Korisnici (ime, prezime, korisnickoIme, lozinka) VALUES ?",
            [noviKorisnik],
            (error, results) => {
                if (error) throw error;
                res.send({ message: "Registracija uspešna", results });
            }
        );
    });
});

// API za login
app.post("/api/login", (req, res) => {
    const { korisnickoIme, lozinka } = req.body;

    connection.query(
        "SELECT * FROM Korisnici WHERE korisnickoIme = ? AND lozinka = ?",
        [korisnickoIme, lozinka],
        (error, results) => {
            if (error) throw error;

            if (results.length === 0) {
                return res.status(400).json({ message: "Pogrešno korisničko ime ili lozinka" });
            }
            res.status(200).json({ message: "Prijava uspešna", data: { korisnickoIme } });
        }
    );
});

// API za pregled narudžbi
app.get("/api/narudzbe", (req, res) => {
    connection.query("SELECT * FROM Narudzbe", (error, results) => {
        if (error) throw error;
        res.send(results);
    });
});

// API za dodavanje narudžbe
app.post("/api/dodaj_narudzbu", (req, res) => {
    const { id_korisnika, id_automobila } = req.body;

    if (!id_korisnika || !id_automobila) {
        return res.status(400).send({ message: "Neispravan ID korisnika ili automobila" });
    }

    connection.query(
        "INSERT INTO Narudzbe (id_korisnika, id_automobila) VALUES (?, ?)",
        [id_korisnika, id_automobila],
        (error, results) => {
            if (error) throw error;
            res.send({ message: "Narudžba uspješno dodana", results });
        }
    );
});

// API za brisanje narudžbi
app.delete("/api/isprazni_narudzbe", (req, res) => {
    connection.query("TRUNCATE TABLE Narudzbe", (error, results) => {
        if (error) throw error;
        res.send({ message: "Sve narudžbe su obrisane", results });
    });
});

// Pokretanje servera
app.listen(3001, () => {
    console.log("Server running on port 3000");
});
